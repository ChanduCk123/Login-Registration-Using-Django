# EMAIL_USE_TLC = True
# EMAIL_HOST = 'smtp.gmail.com'
# EMAIL_HOST_USER = 'r170588@rguktrkv.ac.in'
# EMAIL_HOST_PASSWORD = "Vk@8374274926"
# EMAIL_PORT = 587

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
